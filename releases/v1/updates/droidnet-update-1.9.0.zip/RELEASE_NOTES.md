## Comlink

### Bug Fixes

- **First Comlink command now reliably reaches the WCB.** Fixed a race condition
  where the first Comlink command after a cold connection would silently fail —
  the booster reported success but the bytes were dropped before reaching the
  device. The previous workaround of opening the WCB tab in DroidNet first is no
  longer needed.
- **Comlink history view recovers from corruption automatically.** A torn write
  could previously leave the history file unparseable, causing the history view
  to error every poll and crashing the Comlink service thread on the next
  command. The view now self-heals: corrupt files are preserved as
  `.corrupt.<timestamp>` for diagnosis and a fresh history starts immediately.

## Maestro Tab

### Bug Fixes

- **Sync to Device now works after MCC backup import.** Previously, sequences
  imported from an MCC backup file were created with sync disabled, so Sync to
  Device returned "No sequences marked for device sync" even though the
  confirmation dialog promised "Sync N sequences." Imported sequences now sync
  by default.
- **Sync confirmation and success messages match what is actually uploaded.**
  Mixed libraries (some sequences flagged for sync, some not) no longer produce
  misleading "Sync N" prompts followed by smaller actual upload counts.

## Reliability

### Improvements

- **Hardened Comlink and battery telemetry storage against torn writes.** A
  process kill or system restart in the middle of a save can no longer leave a
  half-written file requiring manual intervention. Comlink command history,
  Comlink active-device list, and Victron telemetry all use atomic writes now.
