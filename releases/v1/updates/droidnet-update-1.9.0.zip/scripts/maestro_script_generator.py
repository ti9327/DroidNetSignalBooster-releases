#!/usr/bin/env python3
"""
Maestro Script Generator

Generates MCC-compatible Maestro scripts from sequences.
Uses helper subroutines for efficient code generation like
Maestro Control Center does.
"""

from typing import Any, List, Dict, Set
import re

# Reserved keywords that cannot be used as subroutine names.
# Must match all keywords recognized by maestro_compiler.py.
RESERVED_KEYWORDS = {
    "quit",
    "return",
    "delay",
    "get_ms",
    "depth",
    "drop",
    "dup",
    "over",
    "pick",
    "swap",
    "rot",
    "roll",
    "bitwise_not",
    "bitwise_and",
    "bitwise_or",
    "bitwise_xor",
    "shift_right",
    "shift_left",
    "not",
    "logical_not",
    "and",
    "logical_and",
    "or",
    "logical_or",
    "negate",
    "plus",
    "minus",
    "times",
    "divide",
    "mod",
    "positive",
    "negative",
    "nonzero",
    "equals",
    "not_equals",
    "min",
    "max",
    "less_than",
    "greater_than",
    "servo",
    "servo_8bit",
    "speed",
    "acceleration",
    "get_position",
    "get_moving_state",
    "led_on",
    "led_off",
    "pwm",
    "peek",
    "poke",
    "serial_send_byte",
    # Flow control keywords
    "begin",
    "repeat",
    "while",
    "if",
    "else",
    "endif",
    "goto",
    "sub",
}

# Safe neutral position for servos (quarter-microseconds)
# Matches MAESTRO_DEFAULTS["neutral"] in server.py and
# MaestroStudioConfig.SERVO_MIN/MAX_DEFAULT center in JS frontend
DEFAULT_NEUTRAL_POSITION = 6000  # 1500µs


def sanitize_name(name: str) -> str:
    """
    Convert a sequence name to a valid subroutine name.

    Rules:
    - Replace spaces with underscores
    - Remove non-alphanumeric characters (except underscore)
    - Must start with letter or underscore
    - Cannot be a reserved keyword
    """
    # Replace spaces with underscores
    name = name.replace(" ", "_")
    # Remove invalid characters
    name = re.sub(r"[^a-zA-Z0-9_]", "", name)
    # Ensure starts with letter or underscore
    if name and name[0].isdigit():
        name = "_" + name
    name = name or "unnamed"
    # Avoid reserved keywords
    if name.lower() in RESERVED_KEYWORDS:
        name = f"seq_{name}"
    return name


def analyze_channel_usage(sequences: List[Dict]) -> Dict[str, Any]:
    """
    Analyze which channels are used in each sequence and across all sequences.

    Returns:
        Dictionary with:
        - 'all': set of all channels used
        - 'per_sequence': list of sets, one per sequence
    """
    all_channels: Set[int] = set()
    per_sequence: List[Set[int]] = []

    for seq in sequences:
        seq_channels: Set[int] = set()
        for frame in seq.get("frames", []):
            positions = frame.get("positions", {})
            for ch_str in positions.keys():
                try:
                    ch = int(ch_str)
                    seq_channels.add(ch)
                    all_channels.add(ch)
                except ValueError:
                    # Skip invalid channel keys (non-numeric)
                    continue
        per_sequence.append(seq_channels)

    return {"all": all_channels, "per_sequence": per_sequence}


def generate_frame_helper(channels: Set[int]) -> str:
    """
    Generate a helper subroutine for setting servo positions.

    MCC generates helpers like:
      sub frame_0..4
        4 servo
        3 servo
        2 servo
        1 servo
        0 servo
        delay
        return

    The stack is expected to have: delay, pos_n, pos_n-1, ..., pos_0
    (delay is deepest, positions are in reverse channel order)
    """
    if not channels:
        return ""

    sorted_channels = sorted(channels, reverse=True)
    min_ch = min(channels)
    max_ch = max(channels)

    # Name the helper based on channel range
    if min_ch == max_ch:
        helper_name = f"frame_{min_ch}"
    else:
        helper_name = f"frame_{min_ch}..{max_ch}"

    lines = [f"sub {helper_name}"]

    # Pop positions from stack and set servos (reverse order of channels)
    for ch in sorted_channels:
        lines.append(f"  {ch} servo")

    # Delay
    lines.append("  delay")
    lines.append("  return")

    return "\n".join(lines)


def generate_sequence_subroutine(
    sequence: Dict, helper_name: str, channels: Set[int]
) -> str:
    """
    Generate a subroutine for a sequence.

    Format:
      sub SequenceName
        duration pos_n pos_n-1 ... pos_0 frame_helper
        duration pos_n pos_n-1 ... pos_0 frame_helper
        return

    For smooth frames, speed/accel commands are emitted inline before
    the helper call so device-synced playback matches live preview.
    """
    name = sanitize_name(sequence.get("name", "unnamed"))
    frames = sequence.get("frames", [])

    if not frames:
        return f"sub {name}\n  return"

    sorted_channels = sorted(channels, reverse=True)
    sorted_channels_asc = sorted(channels)
    lines = [f"sub {name}"]

    prev_pos: Dict[int, int] = {}
    in_smooth_section = False

    for i, frame in enumerate(frames):
        duration = frame.get("duration", 500)
        # Validate duration (1-65535ms range)
        if not isinstance(duration, (int, float)):
            duration = 500
        duration = max(1, min(int(duration), 65535))

        positions = frame.get("positions", {})
        is_smooth = frame.get("smooth", False)

        if is_smooth:
            # Accel preamble at first smooth frame in a section
            if not in_smooth_section:
                lines.append("  # Smooth dynamics")
                for ch in sorted_channels_asc:
                    lines.append(f"  0 {ch} acceleration")
                in_smooth_section = True

            # Speed commands (skip first frame - no delta available)
            if prev_pos:
                for ch in sorted_channels_asc:
                    pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
                    if not isinstance(pos, (int, float)):
                        pos = DEFAULT_NEUTRAL_POSITION
                    pos = int(pos)
                    prev = prev_pos.get(ch, pos)
                    delta = abs(pos - prev)
                    spd = max(1, (delta * 10) // duration) if delta > 0 else 0
                    lines.append(f"  {spd} {ch} speed")
        else:
            # Snappy frame: reset speed if leaving a smooth section
            if in_smooth_section:
                lines.append("  # Reset speed (snappy)")
                for ch in sorted_channels_asc:
                    lines.append(f"  0 {ch} speed")
                in_smooth_section = False

        # Build frame line: duration pos_n pos_n-1 ... pos_0 helper
        values = [str(duration)]
        for ch in sorted_channels:
            # Use safe neutral position as default instead of 0
            pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
            # Validate position is numeric
            if not isinstance(pos, (int, float)):
                pos = DEFAULT_NEUTRAL_POSITION
            values.append(str(int(pos)))
        values.append(helper_name)

        lines.append("  " + " ".join(values))

        # Track positions for next frame's delta calculation
        for ch in sorted_channels:
            pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
            if not isinstance(pos, (int, float)):
                pos = DEFAULT_NEUTRAL_POSITION
            prev_pos[ch] = int(pos)

    lines.append("  return")
    return "\n".join(lines)


def generate_mcc_style_script(sequences: List[Dict], channel_count: int = 18) -> str:
    """
    Generate an MCC-compatible script from sequences.

    This generates:
    1. A helper subroutine for setting servo positions and delay
    2. One subroutine per sequence that calls the helper

    Args:
        sequences: List of sequence dictionaries with 'name' and 'frames'
        channel_count: Total number of channels on the device

    Returns:
        Complete script source code
    """
    if not sequences:
        return "# No sequences to generate"

    # Analyze channel usage
    usage = analyze_channel_usage(sequences)
    all_channels = usage["all"]

    if not all_channels:
        return "# No channel positions in sequences"

    # Generate helper subroutine name
    min_ch = min(all_channels)
    max_ch = max(all_channels)
    if min_ch == max_ch:
        helper_name = f"frame_{min_ch}"
    else:
        helper_name = f"frame_{min_ch}..{max_ch}"

    # Build script
    lines = []
    lines.append("# Auto-generated Maestro script")
    lines.append(f"# Generated for channels {min_ch}-{max_ch}")
    lines.append("")

    # Generate helper subroutine
    lines.append(generate_frame_helper(all_channels))
    lines.append("")

    # Generate sequence subroutines
    for seq in sequences:
        lines.append(generate_sequence_subroutine(seq, helper_name, all_channels))
        lines.append("")

    return "\n".join(lines)


def generate_simple_script(sequence: Dict, loop: bool = False) -> str:
    """
    Generate a simple script for a single sequence.

    This generates direct servo commands without helper subroutines,
    useful for quick testing or simple sequences.

    For smooth frames, speed and acceleration commands are emitted
    inline so device-synced playback matches live preview.

    Args:
        sequence: Sequence dictionary with 'name' and 'frames'
        loop: Whether to loop the sequence

    Returns:
        Script source code
    """
    frames = sequence.get("frames", [])

    lines = []
    lines.append(f"# Sequence: {sequence.get('name', 'Unnamed')}")
    lines.append("")

    if loop:
        lines.append("begin")

    prev_pos: Dict[int, int] = {}
    in_smooth_section = False

    for i, frame in enumerate(frames):
        duration = frame.get("duration", 500)
        # Validate duration
        if not isinstance(duration, (int, float)):
            duration = 500
        duration = max(1, min(int(duration), 65535))

        positions = frame.get("positions", {})
        is_smooth = frame.get("smooth", False)

        # Sort channels for consistent output
        sorted_items = sorted(
            positions.items(),
            key=lambda x: int(x[0]) if x[0].isdigit() else 0,
        )

        lines.append(f"  # Frame {i + 1} ({duration}ms)")

        if is_smooth:
            # Accel preamble at first smooth frame in a section
            if not in_smooth_section:
                for ch_str, _ in sorted_items:
                    try:
                        ch = int(ch_str)
                        lines.append(f"  0 {ch} acceleration")
                    except ValueError:
                        continue
                in_smooth_section = True

            # Speed commands (skip first frame - no delta)
            if prev_pos:
                for ch_str, pos in sorted_items:
                    try:
                        ch = int(ch_str)
                        if not isinstance(pos, (int, float)):
                            pos = DEFAULT_NEUTRAL_POSITION
                        pos = int(pos)
                        prev = prev_pos.get(ch, pos)
                        delta = abs(pos - prev)
                        spd = max(1, (delta * 10) // duration) if delta > 0 else 0
                        lines.append(f"  {spd} {ch} speed")
                    except ValueError:
                        continue
        else:
            # Snappy frame: reset speed if leaving a smooth section
            if in_smooth_section:
                for ch_str, _ in sorted_items:
                    try:
                        ch = int(ch_str)
                        lines.append(f"  0 {ch} speed")
                    except ValueError:
                        continue
                in_smooth_section = False

        # Servo commands
        for ch_str, pos in sorted_items:
            try:
                ch = int(ch_str)
                # Validate position
                if not isinstance(pos, (int, float)):
                    pos = DEFAULT_NEUTRAL_POSITION
                lines.append(f"  {int(pos)} {ch} servo")
            except ValueError:
                continue  # Skip invalid channel keys
        lines.append(f"  {duration} delay")
        lines.append("")

        # Track positions for next frame's delta calculation
        for ch_str, pos in sorted_items:
            try:
                ch = int(ch_str)
                if not isinstance(pos, (int, float)):
                    pos = DEFAULT_NEUTRAL_POSITION
                prev_pos[ch] = int(pos)
            except ValueError:
                continue

    if loop:
        lines.append("repeat")
    else:
        lines.append("quit")

    return "\n".join(lines)


def _literal_size(value: int) -> int:
    """Return the bytecode size of an integer literal.

    Values 0-255: LITERAL8 (opcode + 1 byte) = 2 bytes.
    Other signed 16-bit values: LITERAL (opcode + 2 bytes LE) = 3 bytes.
    """
    if 0 <= value <= 255:
        return 2
    return 3


def estimate_bytecode_size(sequence: Dict, use_helper: bool = True) -> int:
    """
    Estimate the bytecode size for a sequence.

    Computes actual speed values from frame deltas to determine
    encoding size accurately.

    Args:
        sequence: Sequence dict with 'frames' list
        use_helper: If True, estimate MCC-style (helper subroutine).
                    If False, estimate simple inline style.

    Returns:
        Estimated bytecode size in bytes
    """
    frames = sequence.get("frames", [])
    if not frames:
        # Empty subroutine: just a return opcode
        return 1

    # Gather all channels used
    all_channels: Set[int] = set()
    for frame in frames:
        for ch_str in frame.get("positions", {}).keys():
            try:
                all_channels.add(int(ch_str))
            except ValueError:
                continue

    if not all_channels:
        return 1

    num_channels = len(all_channels)
    sorted_channels = sorted(all_channels)

    size = 0

    if use_helper:
        # Helper subroutine body: N x (channel_literal + servo) + delay + return
        helper_size = sum(_literal_size(ch) + 1 for ch in sorted_channels) + 1 + 1
        size += helper_size

    prev_pos: Dict[int, int] = {}
    in_smooth_section = False

    for i, frame in enumerate(frames):
        duration = frame.get("duration", 500)
        if not isinstance(duration, (int, float)):
            duration = 500
        duration = max(1, min(int(duration), 65535))

        positions = frame.get("positions", {})
        is_smooth = frame.get("smooth", False)

        if is_smooth:
            # Accel preamble at first smooth frame
            if not in_smooth_section:
                # 0 ch acceleration = LITERAL8(0) + LITERAL8(ch) + accel
                # = 2 + 2 + 1 = 5 bytes per channel (ch 0-255)
                size += 5 * num_channels
                in_smooth_section = True

            # Speed commands (skip first frame)
            if prev_pos:
                for ch in sorted_channels:
                    pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
                    if not isinstance(pos, (int, float)):
                        pos = DEFAULT_NEUTRAL_POSITION
                    pos = int(pos)
                    prev = prev_pos.get(ch, pos)
                    delta = abs(pos - prev)
                    spd = max(1, (delta * 10) // duration) if delta > 0 else 0
                    # speed_literal + channel_literal + speed_opcode
                    size += _literal_size(spd)
                    size += _literal_size(ch)
                    size += 1  # speed opcode
        else:
            # Reset speed if leaving smooth section
            if in_smooth_section:
                # 0 ch speed = LITERAL8(0) + LITERAL8(ch) + speed = 5 bytes/ch
                size += 5 * num_channels
                in_smooth_section = False

        if use_helper:
            # Frame call: duration literal + N position literals
            # + subroutine call (1 byte)
            size += _literal_size(duration)
            for ch in sorted_channels:
                pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
                if not isinstance(pos, (int, float)):
                    pos = DEFAULT_NEUTRAL_POSITION
                size += _literal_size(int(pos))
            size += 1  # subroutine call opcode
        else:
            # Inline: N x (pos literal + ch literal + servo opcode)
            # + duration literal + delay opcode
            for ch in sorted_channels:
                pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
                if not isinstance(pos, (int, float)):
                    pos = DEFAULT_NEUTRAL_POSITION
                size += _literal_size(int(pos))
                size += _literal_size(ch)
                size += 1  # servo opcode
            size += _literal_size(duration)
            size += 1  # delay opcode

        # Track positions for next frame
        for ch in sorted_channels:
            pos = positions.get(str(ch), DEFAULT_NEUTRAL_POSITION)
            if not isinstance(pos, (int, float)):
                pos = DEFAULT_NEUTRAL_POSITION
            prev_pos[ch] = int(pos)

    # Sequence subroutine return opcode
    size += 1

    return size


if __name__ == "__main__":
    # Example usage
    sequences = [
        {
            "name": "00Scream",
            "frames": [
                {"duration": 100, "positions": {"0": 4032, "1": 4416, "2": 4416}},
                {"duration": 2000, "positions": {"0": 6848, "1": 7232, "2": 7232}},
            ],
        },
        {
            "name": "01Short Circuit",
            "frames": [
                {"duration": 500, "positions": {"0": 6000, "1": 6000, "2": 6000}},
                {"duration": 100, "positions": {"0": 4000, "1": 4000, "2": 4000}},
            ],
        },
    ]

    print("=== MCC-Style Script ===")
    print(generate_mcc_style_script(sequences))
    print()
    print("=== Simple Script (with loop) ===")
    print(generate_simple_script(sequences[0], loop=True))
