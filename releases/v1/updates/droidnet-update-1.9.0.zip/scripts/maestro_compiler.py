#!/usr/bin/env python3
"""
Maestro Script Compiler

Compiles Maestro script source code to bytecode that can be
uploaded to Pololu Maestro servo controllers.

Opcode values from papabricole/Pololu-Maestro src/maestro/Opcode.h,
cross-validated against the official Pololu USB SDK (Usc.cs) and
the Pololu Maestro User Guide.
"""

import re
from enum import IntEnum
from typing import List, Dict, Tuple, Optional


class Opcode(IntEnum):
    """Maestro bytecode opcodes -- correct Pololu values."""

    QUIT = 0
    LITERAL = 1
    LITERAL8 = 2
    LITERAL_N = 3
    LITERAL8_N = 4
    RETURN = 5
    JUMP = 6
    JUMP_Z = 7
    DELAY = 8
    GET_MS = 9
    DEPTH = 10
    DROP = 11
    DUP = 12
    OVER = 13
    PICK = 14
    SWAP = 15
    ROT = 16
    ROLL = 17
    BITWISE_NOT = 18
    BITWISE_AND = 19
    BITWISE_OR = 20
    BITWISE_XOR = 21
    SHIFT_RIGHT = 22
    SHIFT_LEFT = 23
    LOGICAL_NOT = 24
    LOGICAL_AND = 25
    LOGICAL_OR = 26
    NEGATE = 27
    PLUS = 28
    MINUS = 29
    TIMES = 30
    DIVIDE = 31
    MOD = 32
    POSITIVE = 33
    NEGATIVE = 34
    NONZERO = 35
    EQUALS = 36
    NOT_EQUALS = 37
    MIN = 38
    MAX = 39
    LESS_THAN = 40
    GREATER_THAN = 41
    SERVO = 42
    SERVO_8BIT = 43
    SPEED = 44
    ACCELERATION = 45
    GET_POSITION = 46
    GET_MOVING_STATE = 47
    LED_ON = 48
    LED_OFF = 49
    PWM = 50
    PEEK = 51
    POKE = 52
    SERIAL_SEND_BYTE = 53
    CALL = 54


# Opcodes that require Mini Maestro (12/18/24-channel)
MINI_MAESTRO_ONLY = {Opcode.PWM, Opcode.PEEK, Opcode.POKE, Opcode.SERIAL_SEND_BYTE}


class CompileError(Exception):
    """Raised when compilation fails."""

    pass


# Placeholder address used during compilation, replaced in final pass
_PLACEHOLDER = 0xFFFF

# Map of keywords to opcodes (simple 1-byte instructions)
KEYWORDS = {
    "quit": Opcode.QUIT,
    # NOTE: "return" is handled specially in _compile_token (checks subroutine
    # context) and is NOT in this dict. Do not add it here.
    "delay": Opcode.DELAY,
    "get_ms": Opcode.GET_MS,
    "depth": Opcode.DEPTH,
    "drop": Opcode.DROP,
    "dup": Opcode.DUP,
    "over": Opcode.OVER,
    "pick": Opcode.PICK,
    "swap": Opcode.SWAP,
    "rot": Opcode.ROT,
    "roll": Opcode.ROLL,
    "bitwise_not": Opcode.BITWISE_NOT,
    "bitwise_and": Opcode.BITWISE_AND,
    "bitwise_or": Opcode.BITWISE_OR,
    "bitwise_xor": Opcode.BITWISE_XOR,
    "shift_right": Opcode.SHIFT_RIGHT,
    "shift_left": Opcode.SHIFT_LEFT,
    "not": Opcode.LOGICAL_NOT,
    "logical_not": Opcode.LOGICAL_NOT,
    "and": Opcode.LOGICAL_AND,
    "logical_and": Opcode.LOGICAL_AND,
    "or": Opcode.LOGICAL_OR,
    "logical_or": Opcode.LOGICAL_OR,
    "negate": Opcode.NEGATE,
    "plus": Opcode.PLUS,
    "minus": Opcode.MINUS,
    "times": Opcode.TIMES,
    "divide": Opcode.DIVIDE,
    "mod": Opcode.MOD,
    "positive": Opcode.POSITIVE,
    "negative": Opcode.NEGATIVE,
    "nonzero": Opcode.NONZERO,
    "equals": Opcode.EQUALS,
    "not_equals": Opcode.NOT_EQUALS,
    "min": Opcode.MIN,
    "max": Opcode.MAX,
    "less_than": Opcode.LESS_THAN,
    "greater_than": Opcode.GREATER_THAN,
    "servo": Opcode.SERVO,
    "servo_8bit": Opcode.SERVO_8BIT,
    "speed": Opcode.SPEED,
    "acceleration": Opcode.ACCELERATION,
    "get_position": Opcode.GET_POSITION,
    "get_moving_state": Opcode.GET_MOVING_STATE,
    "led_on": Opcode.LED_ON,
    "led_off": Opcode.LED_OFF,
    "pwm": Opcode.PWM,
    "peek": Opcode.PEEK,
    "poke": Opcode.POKE,
    "serial_send_byte": Opcode.SERIAL_SEND_BYTE,
}

# Operator aliases
KEYWORD_ALIASES = {
    "+": Opcode.PLUS,
    "-": Opcode.MINUS,
    "*": Opcode.TIMES,
    "/": Opcode.DIVIDE,
    "%": Opcode.MOD,
    "=": Opcode.EQUALS,
    "!=": Opcode.NOT_EQUALS,
    "<": Opcode.LESS_THAN,
    ">": Opcode.GREATER_THAN,
    "&&": Opcode.LOGICAL_AND,
    "||": Opcode.LOGICAL_OR,
    "!": Opcode.LOGICAL_NOT,
    "~": Opcode.BITWISE_NOT,
    "&": Opcode.BITWISE_AND,
    "|": Opcode.BITWISE_OR,
    "^": Opcode.BITWISE_XOR,
    "<<": Opcode.SHIFT_LEFT,
    ">>": Opcode.SHIFT_RIGHT,
}

# Flow control keywords handled specially (not simple opcodes)
FLOW_KEYWORDS = {"begin", "repeat", "while", "if", "else", "endif", "goto"}


class MaestroCompiler:
    """
    Compiles Maestro script source to bytecode.

    Three-pass compilation:
      Pass 1: Collect subroutine names and indices
      Pass 2: Parse tokens, emit bytecode with placeholder addresses
      Pass 3: Resolve labels, fill in JUMP/JUMP_Z targets

    Supports:
    - All 55 Pololu opcodes with correct values
    - LITERAL8 (2 bytes) for values 0-255
    - LITERAL (3 bytes) for signed 16-bit values outside 0-255
    - Flow control compiled to JUMP/JUMP_Z with address resolution
    - BEGIN/WHILE/REPEAT loops
    - IF/ELSE/ENDIF conditionals
    - GOTO with labels (label_name:)
    - Subroutine definitions and calls (128+N for 0-127, CALL for 128+)
    - Mini Maestro-only opcode gating
    - Comments: # or //
    """

    def __init__(self):
        self.reset()

    def reset(self):
        """Reset compiler state."""
        self.bytecode = bytearray()
        self.subroutines: Dict[str, int] = {}  # name (lowercase) -> index
        self.subroutine_names: Dict[str, str] = {}  # lowercase -> original
        self.errors: List[str] = []
        self.line_num = 0
        self.in_subroutine = False
        self.current_subroutine: Optional[str] = None
        self.is_mini_maestro = True

        # Flow control state
        self._block_counter = 0
        self._flow_stack: List[Tuple[str, int]] = []  # (type, block_id)
        self._labels: Dict[str, int] = {}  # label -> bytecode offset
        self._fixups: List[Tuple[int, str]] = []  # (offset, label) to resolve

        # LITERAL8_N batching: buffer consecutive 0-255 values
        self._pending_lit8: List[int] = []

    def compile(
        self, source: str, is_mini_maestro: bool = True
    ) -> Tuple[bytes, List[str]]:
        """
        Compile script source to bytecode.

        Args:
            source: Script source code
            is_mini_maestro: If True, allow PEEK/POKE/PWM/SERIAL_SEND_BYTE

        Returns:
            Tuple of (bytecode, error_list)
        """
        self.reset()
        self.is_mini_maestro = is_mini_maestro

        lines = source.strip().split("\n")

        # Pass 1: collect subroutine names
        for i, line in enumerate(lines):
            clean = _strip_comments(line).strip()
            if clean.lower().startswith("sub "):
                original_name = clean[4:].strip()
                name_lower = original_name.lower()
                if name_lower in self.subroutines:
                    self.errors.append(
                        f"Line {i + 1}: Duplicate subroutine '{original_name}'"
                    )
                elif (
                    name_lower in KEYWORDS
                    or name_lower in FLOW_KEYWORDS
                    or name_lower == "sub"
                ):
                    self.errors.append(
                        f"Line {i + 1}: Reserved keyword as subroutine "
                        f"name: '{original_name}'"
                    )
                else:
                    sub_index = len(self.subroutines)
                    self.subroutines[name_lower] = sub_index
                    self.subroutine_names[name_lower] = original_name

        if self.errors:
            return bytes(), self.errors

        # Pass 2: compile tokens with placeholder addresses
        for i, line in enumerate(lines):
            self.line_num = i + 1
            try:
                self._compile_line(line)
            except CompileError as e:
                self.errors.append(f"Line {self.line_num}: {e}")
            except Exception as e:
                self.errors.append(f"Line {self.line_num}: Internal error: {e}")

        # Flush any remaining buffered literals
        self._flush_literals()

        # Check for unclosed flow control blocks
        if self._flow_stack:
            block_type, _ = self._flow_stack[-1]
            self.errors.append(f"Unclosed '{block_type}' block")

        if self.errors:
            return bytes(), self.errors

        # Pass 3: resolve label fixups
        for offset, label in self._fixups:
            if label not in self._labels:
                self.errors.append(f"Unresolved label: {label}")
                continue
            addr = self._labels[label]
            self.bytecode[offset] = addr & 0xFF
            self.bytecode[offset + 1] = (addr >> 8) & 0xFF

        return bytes(self.bytecode), self.errors

    def _new_block_id(self) -> int:
        self._block_counter += 1
        return self._block_counter

    def _emit_byte(self, value: int):
        self.bytecode.append(value & 0xFF)

    def _flush_literals(self):
        """Flush pending LITERAL8 buffer.

        For 3+ consecutive 0-255 values, emit LITERAL8_N (N+2 bytes).
        For 1-2 values, emit individual LITERAL8 (2 bytes each).
        """
        if not self._pending_lit8:
            return
        if len(self._pending_lit8) >= 3:
            self._emit_byte(Opcode.LITERAL8_N)
            self._emit_byte(len(self._pending_lit8))
            for v in self._pending_lit8:
                self._emit_byte(v)
        else:
            for v in self._pending_lit8:
                self._emit_byte(Opcode.LITERAL8)
                self._emit_byte(v)
        self._pending_lit8 = []

    def _emit_jump(self, opcode: Opcode, label: str):
        """Emit a JUMP or JUMP_Z with a placeholder address to be resolved."""
        self._flush_literals()
        self._emit_byte(opcode)
        offset = len(self.bytecode)
        self._emit_byte(0xFF)  # placeholder lo
        self._emit_byte(0xFF)  # placeholder hi
        self._fixups.append((offset, label))

    def _set_label(self, label: str):
        """Record current bytecode position as a label."""
        self._flush_literals()
        self._labels[label] = len(self.bytecode)

    def _compile_line(self, line: str):
        """Compile a single line."""
        line = _strip_comments(line).strip()
        if not line:
            return

        # Label definition: "name:"
        if re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*:$", line):
            label_name = "USER_" + line[:-1].lower()
            if label_name in self._labels:
                raise CompileError(f"Duplicate label: {line[:-1]}")
            self._set_label(label_name)
            return

        # Subroutine definition
        if line.lower().startswith("sub "):
            name = line[4:].strip().lower()
            self.in_subroutine = True
            self.current_subroutine = name
            self._set_label(f"SUB_{name}")
            return

        tokens = _tokenize(line)
        for token in tokens:
            self._compile_token(token)

    def _compile_token(self, token: str):
        """Compile a single token to bytecode."""
        token_lower = token.lower()

        # Numeric literal -- buffer for potential LITERAL8_N batching
        if _is_number(token):
            self._encode_literal(int(token))
            return

        # Any non-literal token: flush the literal buffer first
        self._flush_literals()

        # Flow control keywords
        if token_lower in FLOW_KEYWORDS:
            self._compile_flow_control(token_lower)
            return

        # Return (special: exits subroutine)
        if token_lower == "return":
            if not self.in_subroutine:
                raise CompileError("'return' outside of subroutine")
            self._emit_byte(Opcode.RETURN)
            self.in_subroutine = False
            self.current_subroutine = None
            return

        # Simple opcode keywords
        if token_lower in KEYWORDS:
            opcode = KEYWORDS[token_lower]
            if opcode in MINI_MAESTRO_ONLY and not self.is_mini_maestro:
                raise CompileError(
                    f"'{token}' requires Mini Maestro (12/18/24-channel)"
                )
            self._emit_byte(opcode)
            return

        # Operator aliases
        if token in KEYWORD_ALIASES:
            self._emit_byte(KEYWORD_ALIASES[token])
            return

        # Subroutine call
        if token_lower in self.subroutines:
            sub_index = self.subroutines[token_lower]
            if sub_index < 128:
                self._emit_byte(128 + sub_index)
            else:
                # CALL opcode + 2-byte address (Mini Maestro only)
                if not self.is_mini_maestro:
                    raise CompileError(
                        f"Subroutine index {sub_index} >= 128 requires "
                        f"Mini Maestro CALL opcode"
                    )
                self._emit_jump(Opcode.CALL, f"SUB_{token_lower}")
            return

        raise CompileError(f"Unknown token: '{token}'")

    def _compile_flow_control(self, keyword: str):
        """Compile flow control keywords to JUMP/JUMP_Z."""
        if keyword == "begin":
            bid = self._new_block_id()
            self._set_label(f"begin_{bid}")
            self._flow_stack.append(("begin", bid))

        elif keyword == "while":
            if not self._flow_stack or self._flow_stack[-1][0] != "begin":
                raise CompileError("'while' without matching 'begin'")
            _, bid = self._flow_stack[-1]
            # JUMP_Z to after the repeat
            self._emit_jump(Opcode.JUMP_Z, f"end_{bid}")

        elif keyword == "repeat":
            if not self._flow_stack or self._flow_stack[-1][0] != "begin":
                raise CompileError("'repeat' without matching 'begin'")
            _, bid = self._flow_stack.pop()
            # JUMP back to begin
            self._emit_jump(Opcode.JUMP, f"begin_{bid}")
            # Label for while's JUMP_Z target
            self._set_label(f"end_{bid}")

        elif keyword == "if":
            bid = self._new_block_id()
            # JUMP_Z to else/endif
            self._emit_jump(Opcode.JUMP_Z, f"else_{bid}")
            self._flow_stack.append(("if", bid))

        elif keyword == "else":
            if not self._flow_stack or self._flow_stack[-1][0] != "if":
                raise CompileError("'else' without matching 'if'")
            _, bid = self._flow_stack[-1]
            self._flow_stack[-1] = ("else", bid)
            # JUMP past the else block
            self._emit_jump(Opcode.JUMP, f"endif_{bid}")
            # Label for if's JUMP_Z
            self._set_label(f"else_{bid}")

        elif keyword == "endif":
            if not self._flow_stack or self._flow_stack[-1][0] not in (
                "if",
                "else",
            ):
                raise CompileError("'endif' without matching 'if'")
            block_type, bid = self._flow_stack.pop()
            if block_type == "if":
                # No else: if's JUMP_Z lands here
                self._set_label(f"else_{bid}")
            else:
                # Has else: jump from end of if-body lands here
                self._set_label(f"endif_{bid}")

        elif keyword == "goto":
            raise CompileError("GOTO requires a label argument (use 'goto label_name')")

    def _encode_literal(self, value: int):
        """
        Encode a numeric literal.

        Values 0-255 are buffered for potential LITERAL8_N batch encoding.
        Values outside 0-255 flush the buffer and emit LITERAL (3 bytes).
        The buffer is flushed by _flush_literals() when a non-literal token
        is encountered, emitting LITERAL8_N for 3+ values or individual
        LITERAL8 for 1-2 values.
        """
        if value < -32768 or value > 32767:
            raise CompileError(f"Literal out of signed 16-bit range: {value}")

        if 0 <= value <= 255:
            self._pending_lit8.append(value)
        else:
            # Large literal breaks the batch
            self._flush_literals()
            if value < 0:
                value = value & 0xFFFF  # Two's complement
            self._emit_byte(Opcode.LITERAL)
            self._emit_byte(value & 0xFF)
            self._emit_byte((value >> 8) & 0xFF)

    def get_subroutine_map(self) -> Dict[int, str]:
        """Get mapping of subroutine index to name (original case)."""
        return {
            idx: self.subroutine_names.get(name_lower, name_lower)
            for name_lower, idx in self.subroutines.items()
        }


def _strip_comments(line: str) -> str:
    """Remove comments from a line."""
    if "#" in line:
        line = line[: line.index("#")]
    if "//" in line:
        line = line[: line.index("//")]
    return line


def _tokenize(line: str) -> List[str]:
    """Split line into tokens."""
    # Match: negative numbers, words (allow dots for names like frame_0..1),
    # multi-char operators, single-char operators
    pattern = (
        r"(-?\d+)"
        r"|([a-zA-Z_][a-zA-Z0-9_.]*)"
        r"|([!=<>]=|&&|\|\||<<|>>|[+\-*/%=<>!~&|^])"
    )
    return [m.group() for m in re.finditer(pattern, line)]


def _is_number(token: str) -> bool:
    """Check if token is a numeric literal."""
    try:
        int(token)
        return True
    except ValueError:
        return False


def compile_script(
    source: str, is_mini_maestro: bool = True
) -> Tuple[bytes, List[str], Dict[int, str]]:
    """
    Convenience function to compile a script.

    Args:
        source: Script source code
        is_mini_maestro: If True, allow Mini Maestro-only opcodes

    Returns:
        Tuple of (bytecode, errors, subroutine_map)
    """
    compiler = MaestroCompiler()
    bytecode, errors = compiler.compile(source, is_mini_maestro=is_mini_maestro)
    subroutine_map = compiler.get_subroutine_map()
    return bytecode, errors, subroutine_map
