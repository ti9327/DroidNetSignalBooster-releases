#!/usr/bin/env python3
"""
Maestro Optimized Script Generator

Generates compact Maestro scripts using runtime pattern decoding.
Instead of storing pre-computed positions per beat, stores energy/duration
streams and a decoder subroutine that reconstructs positions at runtime.

This reduces script size from ~8,700 bytes to ~635-1,263 bytes per song,
enabling 6-12 songs in the 8 KB Maestro EEPROM.
"""

import math
import re
from typing import List, Dict, Optional

# ── Openness table generators ──────────────────────────────────────


def _breathe_table(n: int) -> List[int]:
    """Power-sine breathe curve: (1 - cos(2*pi*i/n))^0.4 / 2, scaled 0-100."""
    return [
        round(pow((1 - math.cos(2 * math.pi * i / n)) / 2, 0.4) * 100) for i in range(n)
    ]


def _wave_table(n: int) -> List[int]:
    """Standard sine wave: (1 - cos(2*pi*i/n)) / 2, scaled 0-100."""
    return [round((1 - math.cos(2 * math.pi * i / n)) / 2 * 100) for i in range(n)]


def _swell_table() -> List[int]:
    """Swell: exponential rise then snap-close.
    Steps 0-1: ((step+1)/2)^1.5 * 0.8; Step 2: 1.0; Step 3: 0.
    """
    return [
        round(pow((0 + 1) / 2, 1.5) * 0.8 * 100),  # step 0: ~28
        round(pow((1 + 1) / 2, 1.5) * 0.8 * 100),  # step 1: 80
        100,  # step 2: full open
        0,  # step 3: snap close
    ]


# ── Pattern definitions ────────────────────────────────────────────

# Category A: uniform patterns (all channels get same openness per step).
# Table values are openness percentages (0-100) indexed by step % stepsPerCycle.
CATEGORY_A_PATTERNS = {
    "burst": {
        "stepsPerCycle": 4,
        "openness": [100, 100, 0, 0],
        "smooth": False,
    },
    "flutter": {
        "stepsPerCycle": 2,
        "openness": [30, 0],
        "smooth": False,
    },
    "heartbeat": {
        "stepsPerCycle": 4,
        "openness": [50, 0, 50, 0],
        "smooth": False,
    },
    "breathe": {
        "stepsPerCycle": 8,
        "openness": _breathe_table(8),
        "smooth": True,
    },
    "wave": {
        "stepsPerCycle": 2,
        "openness": _wave_table(2),
        "smooth": True,
        "accel": 10,
    },
    "swell": {
        "stepsPerCycle": 4,
        "openness": _swell_table(),
        "smooth": True,
    },
    "bounce": {
        "stepsPerCycle": 8,
        "openness": [100, 30, 70, 15, 0, 0, 0, 0],
        "smooth": False,
    },
}

# Category B: index-dependent patterns (per-channel conditions).
# Each defines a function that returns (openness, stepsPerCycle, smooth)
# given channel_index, step, and num_channels.
CATEGORY_B_PATTERNS = {
    "alternating": {"stepsPerCycle": 4, "smooth": False},
    "chase": {"stepsPerCycle": None, "smooth": False},  # N channels
    "buildup": {"stepsPerCycle": None, "smooth": True},  # N+2
    "cascade": {"stepsPerCycle": None, "smooth": True},  # 2N
    "twitch": {"stepsPerCycle": 4, "smooth": False},
    "focus": {"stepsPerCycle": 8, "smooth": True},
    "scatter": {"stepsPerCycle": 8, "smooth": False},
}

# Category C: phase-offset patterns (per-channel phase shift in table).
CATEGORY_C_PATTERNS = {
    "staggered_breathe": {
        "stepsPerCycle": 8,
        "smooth": True,
        "table_size": 16,
        "curve": "power-sine",
    },
    "staggered_wave": {
        "stepsPerCycle": 4,
        "smooth": True,
        "table_size": 16,
        "curve": "sine",
        "accel": 10,
    },
    "crest_wave": {
        "stepsPerCycle": None,  # N channels
        "smooth": True,
        "table_size": 32,
        "curve": "crest-sine",
        "accel": 10,
    },
}

# Static patterns -- no decoder needed, just set positions once
STATIC_PATTERNS = {"open_all", "close_all", "nothing"}

# Patterns that require flat encoding (not optimizable)
FLAT_ONLY_PATTERNS = {"random_walk"}

# Maximum beats per LITERAL8_N batch (stack limit)
SNAPPY_BATCH_SIZE = 56  # 2 bytes/beat: 112 values
SMOOTH_BATCH_SIZE = 37  # 3 bytes/beat: 111 values


# ── Beat quantization ──────────────────────────────────────────────


def quantize_beats(
    beats: List[Dict],
    intensity_mod: float = 1.0,
    speed_mod: float = 1.0,
    smooth: bool = False,
) -> List[Dict]:
    """Quantize beat data to byte-sized values.

    Args:
        beats: List of {"energy": float, "duration_ms": float} dicts
        intensity_mod: Mood-based intensity multiplier (0.5-2.0)
        speed_mod: Mood-based speed multiplier (0.5-2.0)
        smooth: If True, include per-beat speed byte

    Returns:
        List of {"energy": int, "duration": int, "speed": int?} dicts
        where energy is 0-100, duration is in 10ms units, speed is 0-255
    """
    if not beats:
        return []

    # Pre-compensated duration quantization to prevent systematic drift
    cumulative_ideal = 0.0
    cumulative_quantized = 0.0
    quantized = []

    prev_energy = 0.0
    for beat in beats:
        raw_energy = beat.get("energy", 0.0)
        duration_ms = beat.get("duration_ms", 500.0)

        # Quantize energy with intensity mod
        energy_byte = min(100, round(raw_energy * intensity_mod * 100))
        energy_byte = max(0, energy_byte)

        # Pre-compensated duration quantization
        cumulative_ideal += duration_ms
        target = cumulative_ideal - cumulative_quantized
        dur_quantized = round(target / 10) * 10
        dur_quantized = max(10, min(2550, dur_quantized))  # 1-255 in 10ms units
        duration_byte = int(dur_quantized / 10)
        cumulative_quantized += dur_quantized

        result = {"energy": energy_byte, "duration": duration_byte}

        if smooth:
            # Speed byte: delta-based, scaled by /4 for 0-255 range
            # Compute from energy delta (proxy for position delta)
            delta = abs(raw_energy - prev_energy)
            raw_speed = round(delta * 10 / max(duration_ms, 1) * speed_mod * 1000)
            speed_byte = min(255, round(raw_speed / 4))
            result["speed"] = speed_byte
            prev_energy = raw_energy

        quantized.append(result)

    return quantized


# ── Decoder subroutine generators ──────────────────────────────────


def _generate_channel_loop_servo(channels: List[int], position_depth: int) -> List[str]:
    """Generate channel loop: set all channels to position on stack.

    The position is at depth `position_depth` from TOS when the loop starts.

    If channels are contiguous from 0, uses a counter loop (compact).
    Otherwise, unrolls with explicit channel numbers (always correct).
    """
    if channels == list(range(len(channels))):
        # Contiguous from 0: use counter loop
        return [
            "  0",
            f"  begin dup {len(channels)} less_than while",
            f"    dup {position_depth} pick swap servo",
            "    1 plus",
            "  repeat drop",
        ]
    else:
        # Non-contiguous: unroll with actual channel numbers
        lines = []
        for ch in channels:
            lines.append(f"  {position_depth - 1} pick {ch} servo")
        return lines


def generate_category_a_decoder(
    pattern_name: str,
    channels: List[int],
    min_s: int,
    range_s: int,
    smooth: bool = False,
) -> str:
    """Generate a Category A (uniform) decoder subroutine.

    Two-step architecture:
      1. Map step_idx → openness (0-100) via comparison chain
      2. Compute position from energy × openness (single code path)

    This avoids duplicating position calculation in every branch.
    """
    if pattern_name not in CATEGORY_A_PATTERNS:
        raise ValueError(f"Unknown Category A pattern: {pattern_name}")

    pat = CATEGORY_A_PATTERNS[pattern_name]
    table = pat["openness"]
    steps_per_cycle = pat["stepsPerCycle"]
    num_channels = len(channels)

    lines = [f"sub {pattern_name}_frame"]

    # Stack on entry (snappy): ...batch dur energy(TOS)
    # Stack on entry (smooth): ...batch dur energy speed(TOS)

    if smooth:
        lines.append("  # Apply speed to all channels")
        lines.append("  4 times")  # scale speed byte × 4
        if channels == list(range(num_channels)):
            lines.append("  0")
            lines.append(f"  begin dup {num_channels} less_than while")
            lines.append("    dup 2 pick swap speed")
            lines.append("    1 plus")
            lines.append("  repeat drop")
        else:
            for ch in channels:
                lines.append(f"  dup {ch} speed")
        lines.append("  drop")  # drop speed value
        # Stack now: ...batch dur energy(TOS)

    # Step 1: Map step → openness value
    lines.append(f"  0 peek {steps_per_cycle} mod")
    # Stack: ...batch dur energy step_idx(TOS)
    _emit_openness_lookup(lines, table, steps_per_cycle)
    # Stack: ...batch dur energy openness(TOS)

    # Step 2: Compute position from energy and openness (single code path)
    _emit_position_from_openness(lines, min_s, range_s)
    # Stack: ...batch dur position(TOS)

    # Channel loop: set all channels to position
    lines.extend(_generate_channel_loop_servo(channels, position_depth=2))

    # Drop position
    lines.append("  drop")

    # Delay: duration * 10
    lines.append("  10 times delay")

    # Increment step counter
    lines.append("  0 peek 1 plus 0 poke")
    lines.append("  return")

    return "\n".join(lines)


# ── Category B decoder: per-channel openness ──────────────────────


def _get_steps_per_cycle_b(pattern_name: str, num_channels: int) -> int:
    """Get stepsPerCycle for a Category B pattern."""
    pat = CATEGORY_B_PATTERNS[pattern_name]
    spc = pat["stepsPerCycle"]
    if spc is not None:
        return spc
    if pattern_name == "chase":
        return num_channels
    elif pattern_name == "buildup":
        return num_channels + 2
    elif pattern_name == "cascade":
        return num_channels * 2
    return num_channels


def _openness_b_snappy(
    pattern_name: str, ch_idx: int, s: int, num_channels: int
) -> int:
    """Compute openness for snappy Category B patterns."""
    if pattern_name == "alternating":
        even_idx = ch_idx % 2 == 0
        return 100 if (even_idx == (s < 2)) else 0
    elif pattern_name == "chase":
        return 100 if s == ch_idx else 0
    elif pattern_name == "buildup":
        if s < num_channels:
            return 100 if ch_idx <= s else 0
        return 100 if s == num_channels else 0
    elif pattern_name == "cascade":
        if s < num_channels:
            return 100 if ch_idx <= s else 0
        close_step = s - num_channels
        return 100 if ch_idx > close_step else 0
    return 0


def _openness_b_misc(pattern_name: str, ch_idx: int, s: int, num_channels: int) -> int:
    """Compute openness for twitch/focus/scatter patterns."""
    if pattern_name == "twitch":
        twitch_levels = [25, 10, 35, 5]
        should_twitch = (s + ch_idx) % 2 == 0
        return twitch_levels[s] if should_twitch else 0
    elif pattern_name == "focus":
        offsets = [0, 3, 1, 4, 2, 5]
        spot = s // 2
        focused = offsets[spot % len(offsets)] % num_channels
        is_open_phase = s % 2 == 0
        return 100 if (ch_idx == focused and is_open_phase) else 0
    elif pattern_name == "scatter":
        cycle_len = 2 + (ch_idx % 3)
        offset = int(ch_idx * 0.7)
        local_step = (s + offset) % cycle_len
        return 100 if local_step < (cycle_len / 2) else 0
    return 0


def _channel_openness_b(
    pattern_name: str, ch_idx: int, step: int, num_channels: int
) -> int:
    """Compute openness (0-100) for a Category B pattern at given step.

    Used by tests to verify decoder equivalence.
    """
    spc = _get_steps_per_cycle_b(pattern_name, num_channels)
    s = step % spc

    if pattern_name in ("alternating", "chase", "buildup", "cascade"):
        return _openness_b_snappy(pattern_name, ch_idx, s, num_channels)
    return _openness_b_misc(pattern_name, ch_idx, s, num_channels)


def _generate_twitch_openness_sub() -> str:
    """Generate shared subroutine: step_idx(TOS) → openness(TOS)."""
    lines = ["sub twitch_openness"]
    lines.append("  dup 0 equals if drop 25 else")
    lines.append("  dup 1 equals if drop 10 else")
    lines.append("  dup 2 equals if drop 35 else")
    lines.append("  drop 5")
    lines.append("  endif endif endif")
    lines.append("  return")
    return "\n".join(lines)


def generate_category_b_decoder(
    pattern_name: str,
    channels: List[int],
    min_s: int,
    range_s: int,
    smooth: bool = False,
) -> str:
    """Generate a Category B (index-dependent) decoder subroutine.

    Per-channel unrolled: each channel gets its own openness condition,
    then position computation → servo command.
    """
    if pattern_name not in CATEGORY_B_PATTERNS:
        raise ValueError(f"Unknown Category B pattern: {pattern_name}")

    num_channels = len(channels)
    spc = _get_steps_per_cycle_b(pattern_name, num_channels)

    # Twitch uses a shared openness lookup subroutine
    prefix = ""
    if pattern_name == "twitch":
        prefix = _generate_twitch_openness_sub() + "\n"

    lines = [f"sub {pattern_name}_frame"]

    # Stack on entry: ...batch dur energy(TOS)
    if smooth:
        lines.append("  4 times")
        if channels == list(range(num_channels)):
            lines.append("  0")
            lines.append(f"  begin dup {num_channels} less_than while")
            lines.append("    dup 2 pick swap speed")
            lines.append("    1 plus")
            lines.append("  repeat drop")
        else:
            for ch in channels:
                lines.append(f"  dup {ch} speed")
        lines.append("  drop")

    # Compute step index
    lines.append(f"  0 peek {spc} mod")
    # Stack: ...batch dur energy step_idx(TOS)

    if pattern_name == "twitch":
        # Precompute openness once using shared subroutine
        lines.append("  dup twitch_openness")
        # Stack: ...batch dur energy step_idx openness(TOS)

    # Per-channel unrolled blocks
    _emit_category_b_channels(
        lines, pattern_name, channels, min_s, range_s, num_channels
    )
    # Stack: ...batch dur (energy, step, and openness consumed)

    # Delay
    lines.append("  10 times delay")
    lines.append("  0 peek 1 plus 0 poke")
    lines.append("  return")

    return prefix + "\n".join(lines)


def _emit_category_b_channels(
    lines, pattern_name, channels, min_s, range_s, num_channels
):
    """Emit per-channel openness → position → servo blocks.

    Stack on entry (most patterns): ...batch dur energy step_idx(TOS)
    Stack on entry (twitch):        ...batch dur energy step_idx openness(TOS)
    Stack on exit:                  ...batch dur
    """
    for idx, ch in enumerate(channels):
        _emit_b_single_channel(
            lines,
            pattern_name,
            idx,
            ch,
            min_s,
            range_s,
            num_channels,
        )

    # After all channels: clean up stack
    if pattern_name == "twitch":
        lines.append("  drop drop drop")  # openness + step_idx + energy
    else:
        lines.append("  drop drop")  # step_idx + energy


def _emit_b_single_channel(
    lines,
    pattern_name,
    ch_idx,
    ch_num,
    min_s,
    range_s,
    num_channels,
):
    """Emit openness check + position + servo for one channel.

    Stack (most patterns): ...batch dur energy step_idx(TOS)
    Stack (twitch):        ...batch dur energy step_idx openness(TOS)
    Must leave stack unchanged (uses dup/pick for reads).
    """
    min_pos = min_s * 100

    # Emit the condition for this channel being "open"
    if pattern_name == "alternating":
        _emit_alternating_channel(lines, ch_idx, ch_num, min_pos, range_s)
    elif pattern_name == "chase":
        _emit_chase_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels)
    elif pattern_name == "buildup":
        _emit_buildup_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels)
    elif pattern_name == "cascade":
        _emit_cascade_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels)
    elif pattern_name == "twitch":
        _emit_twitch_channel(lines, ch_idx, ch_num, min_pos, range_s)
    elif pattern_name == "focus":
        _emit_focus_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels)
    elif pattern_name == "scatter":
        _emit_scatter_channel(lines, ch_idx, ch_num, min_pos, range_s)


def _emit_open_servo(lines, ch_num, min_s, range_s):
    """Emit: compute position from energy on stack → servo.

    Stack on entry: ...batch dur energy step_idx (energy at depth 1)
    Leaves stack unchanged.
    """
    # Pick energy from depth 1 (below step_idx)
    lines.append("    1 pick")
    # effective = energy * 100 / 100 (openness=100, simplified)
    lines.append(f"    {range_s} times {min_s * 100} plus")
    lines.append(f"    {ch_num} servo")


def _emit_partial_open_servo(lines, ch_num, openness, min_s, range_s):
    """Emit: position with partial openness → servo."""
    lines.append(f"    1 pick {openness} times 100 divide")
    lines.append(f"    {range_s} times {min_s * 100} plus")
    lines.append(f"    {ch_num} servo")


def _emit_closed_servo(lines, ch_num, min_pos):
    """Emit: set channel to min position."""
    lines.append(f"    {min_pos} {ch_num} servo")


def _emit_alternating_channel(lines, ch_idx, ch_num, min_pos, range_s):
    """alternating: even indices open on steps 0-1, odd on steps 2-3."""
    min_s = min_pos // 100
    even = ch_idx % 2 == 0
    if even:
        # Open when step < 2
        lines.append("  dup 2 less_than")
    else:
        # Open when step >= 2
        lines.append("  dup 2 less_than not")
    lines.append("  if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("  else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("  endif")


def _emit_chase_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels):
    """chase: channel open when step == ch_idx."""
    min_s = min_pos // 100
    lines.append(f"  dup {ch_idx} equals")
    lines.append("  if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("  else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("  endif")


def _emit_buildup_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels):
    """buildup: open if step >= ch_idx (opening phase), all open at hold."""
    min_s = min_pos // 100
    # Opening: step < num_channels AND ch_idx <= step → open
    # Hold: step == num_channels → all open
    # Close: step > num_channels → all closed
    lines.append(f"  dup {num_channels} less_than")  # opening phase?
    lines.append("  if")
    lines.append(f"    dup {ch_idx} less_than not")  # step >= ch_idx?
    lines.append("    if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("    else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("    endif")
    lines.append("  else")
    lines.append(f"    dup {num_channels} equals")  # hold phase?
    lines.append("    if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("    else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("    endif")
    lines.append("  endif")


def _emit_cascade_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels):
    """cascade: open cumulatively, then close sequentially."""
    min_s = min_pos // 100
    # Opening: step < N AND ch_idx <= step → open
    # Closing: step >= N AND ch_idx > (step - N) → still open
    lines.append(f"  dup {num_channels} less_than")  # opening?
    lines.append("  if")
    lines.append(f"    dup {ch_idx} less_than not")  # step >= ch_idx?
    lines.append("    if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("    else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("    endif")
    lines.append("  else")
    # close_step = step - num_channels; open if ch_idx > close_step
    lines.append(f"    dup {num_channels} minus")  # close_step on TOS
    lines.append(
        f"    {ch_idx} less_than"
    )  # close_step < ch_idx? (i.e. ch_idx > close_step)
    lines.append("    if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("    else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("    endif")
    lines.append("  endif")


def _emit_twitch_channel(lines, ch_idx, ch_num, min_pos, range_s):
    """twitch: uses precomputed openness from stack.

    Stack: ...batch dur energy step openness(TOS)
    Must leave stack unchanged (uses pick for reads).
    """
    # Check active: (step + ch_idx) % 2 == 0
    lines.append(f"  1 pick {ch_idx} plus 2 mod 0 equals")
    lines.append("  if")
    # Compute position from precomputed openness and energy
    # Stack: ...batch dur energy step openness  (energy at depth 2)
    lines.append("    dup 3 pick times 100 divide")
    lines.append(f"    {range_s} times {min_pos} plus")
    lines.append(f"    {ch_num} servo")
    lines.append("  else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("  endif")


def _emit_focus_channel(lines, ch_idx, ch_num, min_pos, range_s, num_channels):
    """focus: pseudo-random spotlight on one channel at a time."""
    min_s = min_pos // 100
    # The spotlight pattern: step/2 indexes into offsets [0,3,1,4,2,5]
    # Channel is open when it's the focused panel AND step is even
    # For simplicity, emit the open/closed states as a lookup table
    offsets = [0, 3, 1, 4, 2, 5]
    for s in range(8):
        spot = s // 2
        focused = offsets[spot % len(offsets)] % num_channels
        is_open = (ch_idx == focused) and (s % 2 == 0)
        if is_open:
            lines.append(f"  dup {s} equals")
            lines.append("  if")
            _emit_open_servo(lines, ch_num, min_s, range_s)
            lines.append("  else")

    # Default: closed
    _emit_closed_servo(lines, ch_num, min_pos)
    # Close all the if/else chains
    for s in range(8):
        spot = s // 2
        focused = offsets[spot % len(offsets)] % num_channels
        is_open = (ch_idx == focused) and (s % 2 == 0)
        if is_open:
            lines.append("  endif")


def _emit_scatter_channel(lines, ch_idx, ch_num, min_pos, range_s):
    """scatter: per-channel independent cycles."""
    min_s = min_pos // 100
    cycle_len = 2 + (ch_idx % 3)
    offset = int(ch_idx * 0.7)

    # Compute localStep = (step + offset) % cycle_len
    # Open if localStep < cycle_len/2
    if offset > 0:
        lines.append(f"  dup {offset} plus {cycle_len} mod")
    else:
        lines.append(f"  dup {cycle_len} mod")
    half = cycle_len // 2
    if cycle_len % 2 == 1:
        half += 1  # ceil division for odd cycle lengths
    lines.append(f"  {half} less_than")
    lines.append("  if")
    _emit_open_servo(lines, ch_num, min_s, range_s)
    lines.append("  else")
    _emit_closed_servo(lines, ch_num, min_pos)
    lines.append("  endif")


# ── Category C decoder: phase-offset patterns ─────────────────────


def _phase_offset_table(table_size: int, curve: str) -> List[int]:
    """Generate openness lookup table for phase-offset patterns."""
    table = []
    for i in range(table_size):
        phase = 2 * math.pi * i / table_size
        raw = (1 - math.cos(phase)) / 2
        if curve == "power-sine":
            val = pow(raw, 0.4) * 100
        elif curve == "crest-sine":
            val = pow(raw, 2) * 100
        else:  # "sine"
            val = raw * 100
        table.append(round(val))
    return table


def _channel_phase_offset_c(pattern_name: str, ch_idx: int, num_channels: int) -> int:
    """Compute phase offset (table index units) for a channel."""
    pat = CATEGORY_C_PATTERNS[pattern_name]
    table_size = pat["table_size"]
    if pattern_name == "staggered_breathe":
        return round(ch_idx * table_size / num_channels) % table_size
    elif pattern_name == "staggered_wave":
        wave_size = 2  # default
        return round(ch_idx * table_size * wave_size / num_channels) % table_size
    elif pattern_name == "crest_wave":
        # For crest_wave: offset = ch_idx * table_size / num_channels
        return round(ch_idx * table_size / num_channels) % table_size
    return 0


def generate_category_c_decoder(
    pattern_name: str,
    channels: List[int],
    min_s: int,
    range_s: int,
    smooth: bool = True,
) -> str:
    """Generate a Category C (phase-offset) decoder subroutine.

    Each channel indexes into a shared lookup table at a different
    phase offset. The table lookup is extracted into a shared subroutine
    to avoid duplicating the comparison chain per channel.
    """
    if pattern_name not in CATEGORY_C_PATTERNS:
        raise ValueError(f"Unknown Category C pattern: {pattern_name}")

    pat = CATEGORY_C_PATTERNS[pattern_name]
    num_channels = len(channels)
    table_size = pat["table_size"]
    curve = pat["curve"]
    spc = pat["stepsPerCycle"]
    if spc is None:
        spc = num_channels

    table = _phase_offset_table(table_size, curve)
    min_pos = min_s * 100

    # Generate shared table lookup subroutine
    # Stack: table_idx(TOS) → openness(TOS)
    lookup_lines = [f"sub {pattern_name}_lookup"]
    _emit_table_lookup_inline(lookup_lines, table)
    lookup_lines.append("  return")

    lines = [f"sub {pattern_name}_frame"]

    # Stack on entry (smooth): ...batch dur energy speed(TOS)
    if smooth:
        lines.append("  4 times")
        if channels == list(range(num_channels)):
            lines.append("  0")
            lines.append(f"  begin dup {num_channels} less_than while")
            lines.append("    dup 2 pick swap speed")
            lines.append("    1 plus")
            lines.append("  repeat drop")
        else:
            for ch in channels:
                lines.append(f"  dup {ch} speed")
        lines.append("  drop")
    # Stack: ...batch dur energy(TOS)

    # Get table index from step counter
    # step_in_cycle = step_counter % spc
    # table_idx = step_in_cycle * table_size / spc
    if table_size == spc:
        lines.append(f"  0 peek {table_size} mod")
    elif table_size % spc == 0:
        advance = table_size // spc
        lines.append(f"  0 peek {spc} mod {advance} times")
    else:
        lines.append(f"  0 peek {spc} mod {table_size} times {spc} divide")
    # Stack: ...batch dur energy step_in_table(TOS)

    # Per-channel: compute (step + offset) % table_size → call lookup
    for idx, ch in enumerate(channels):
        offset = _channel_phase_offset_c(pattern_name, idx, num_channels)
        # Compute table index for this channel
        if offset > 0:
            lines.append(f"  dup {offset} plus {table_size} mod")
        else:
            lines.append("  dup")
        # Stack: ...batch dur energy step ch_table_idx(TOS)

        # Lookup openness via shared subroutine
        lines.append(f"  {pattern_name}_lookup")
        # Stack: ...batch dur energy step openness(TOS)

        # Compute position
        lines.append("  dup 0 equals")
        lines.append("  if")
        lines.append(f"    drop {min_pos} {ch} servo")
        lines.append("  else")
        lines.append("    2 pick times 100 divide")
        lines.append(f"    {range_s} times {min_pos} plus")
        lines.append(f"    {ch} servo")
        lines.append("  endif")

    lines.append("  drop")  # drop step
    lines.append("  drop")  # drop energy

    # Delay
    lines.append("  10 times delay")
    lines.append("  0 peek 1 plus 0 poke")
    lines.append("  return")

    return "\n".join(lookup_lines) + "\n" + "\n".join(lines)


def _emit_table_index_condition(lines: List[str], indices: List[int]):
    """Emit condition checking if TOS matches any of the given indices.

    Preserves the value below the condition on stack (uses dup).
    """
    if len(indices) == 1:
        lines.append(f"  dup {indices[0]} equals")
    elif indices == list(range(len(indices))):
        lines.append(f"  dup {len(indices)} less_than")
    else:
        lines.append("  dup")
        for s in indices[:-1]:
            lines.append(f"  dup {s} equals swap")
        lines.append(f"  {indices[-1]} equals")
        if len(indices) > 1:
            lines.append("  " + " ".join(["or"] * (len(indices) - 1)))


def _emit_table_lookup_inline(lines: List[str], table: List[int]):
    """Emit inline comparison chain to look up value from table.

    Stack: table_idx(TOS) → value(TOS)
    """
    unique = sorted(set(table))
    if len(unique) == 1:
        lines.append(f"  drop {unique[0]}")
        return

    groups = {}
    for i, v in enumerate(table):
        groups.setdefault(v, []).append(i)

    sorted_groups = sorted(groups.items(), key=lambda x: -len(x[1]))

    last_idx = len(sorted_groups) - 1
    for idx, (val, indices) in enumerate(sorted_groups):
        if idx > 0:
            lines.append("  else")
        if idx < last_idx:
            _emit_table_index_condition(lines, indices)
            lines.append("  if")
        lines.append(f"    drop {val}")

    for _ in range(len(sorted_groups) - 1):
        lines.append("  endif")


# ── Openness lookup (step → openness value) ───────────────────────


def _is_symmetric(table: List[int]) -> bool:
    """Check if table has mirror symmetry: table[i] == table[n-i] for i > 0."""
    n = len(table)
    return all(table[i] == table[n - i] for i in range(1, n // 2 + 1))


def _emit_openness_lookup(lines: List[str], table: List[int], steps_per_cycle: int):
    """Emit code to map step_idx → openness value.

    Stack on entry: ...batch dur energy step_idx(TOS)
    Stack on exit:  ...batch dur energy openness(TOS)

    Strategies:
    - Binary (2 distinct values): single comparison
    - Symmetric tables: fold to half, then lookup
    - General: cascaded if/else chain for each unique value
    """
    unique_vals = sorted(set(table))

    if len(unique_vals) == 1:
        # All same value -- drop step_idx, push constant
        lines.append("  drop")
        lines.append(f"  {unique_vals[0]}")
        return

    if len(unique_vals) == 2 and 0 in unique_vals:
        # Binary on/off -- use simple threshold/comparison
        _emit_binary_lookup(lines, table)
        return

    # Check for symmetry and fold
    if _is_symmetric(table) and len(table) >= 6:
        _emit_folded_lookup(lines, table, steps_per_cycle)
        return

    # General case: cascaded comparisons
    _emit_chain_lookup(lines, table)


def _emit_binary_lookup(lines: List[str], table: List[int]):
    """Binary openness: exactly 0 and one non-zero value.

    Stack: step_idx(TOS) → openness(TOS)
    """
    open_steps = [i for i, v in enumerate(table) if v != 0]
    open_val = table[open_steps[0]]

    # Check if open steps form contiguous range from 0
    if open_steps == list(range(len(open_steps))):
        lines.append(f"  {len(open_steps)} less_than")
    elif len(open_steps) == 1:
        lines.append(f"  {open_steps[0]} equals")
    elif open_steps == list(range(0, len(table), 2)):
        lines.append("  2 mod 0 equals")
    else:
        _emit_membership_check(lines, open_steps)

    lines.append("  if")
    lines.append(f"    {open_val}")
    lines.append("  else")
    lines.append("    0")
    lines.append("  endif")


def _emit_membership_check(lines: List[str], steps: List[int]):
    """Emit check: is step_idx in the given set of step values?

    Consumes step_idx from TOS, pushes boolean result.
    Pattern: for each step except last, do `dup S equals swap`;
    for the last, `S equals`; then chain N-1 `or`s.
    """
    if len(steps) == 1:
        lines.append(f"  {steps[0]} equals")
    elif len(steps) == 2:
        lines.append(f"  dup {steps[0]} equals")
        lines.append(f"  swap {steps[1]} equals or")
    else:
        for s in steps[:-1]:
            lines.append(f"  dup {s} equals swap")
        lines.append(f"  {steps[-1]} equals")
        lines.append("  " + " ".join(["or"] * (len(steps) - 1)))


def _emit_folded_lookup(lines: List[str], table: List[int], steps_per_cycle: int):
    """Emit lookup for symmetric table using folding to halve comparisons.

    For table [0, 46, 76, 94, 100, 94, 76, 46]:
    fold: if step >= 4 then step = 8 - step
    then lookup in half-table [0, 46, 76, 94, 100]
    """
    n = len(table)
    half = n // 2

    # Fold: if step >= half, step = n - step
    lines.append(f"  dup {half} less_than not")
    lines.append("  if")
    lines.append(f"    {n} swap minus")
    lines.append("  endif")
    # Stack: ...batch dur energy folded_step (0 to half)

    # Build half-table (first half + peak)
    half_table = table[: half + 1]
    _emit_chain_lookup(lines, half_table)


def _emit_step_match_condition(lines: List[str], steps: List[int]):
    """Emit condition: does step_idx (TOS) match any of the given steps?

    Leaves step_idx on stack (uses dup). Pushes boolean result.
    Pattern: dup to preserve step_idx, then membership check on the copy.
    """
    if len(steps) == 1:
        lines.append(f"  dup {steps[0]} equals")
    elif steps == list(range(len(steps))):
        lines.append(f"  dup {len(steps)} less_than")
    else:
        # dup preserves step_idx; then membership check consumes the copy
        lines.append("  dup")
        for s in steps[:-1]:
            lines.append(f"  dup {s} equals swap")
        lines.append(f"  {steps[-1]} equals")
        lines.append("  " + " ".join(["or"] * (len(steps) - 1)))


def _group_table_by_value(table: List[int]) -> List:
    """Group table indices by their openness value, sorted by frequency."""
    groups: Dict[int, List[int]] = {}
    for i, v in enumerate(table):
        groups.setdefault(v, []).append(i)
    return sorted(groups.items(), key=lambda x: -len(x[1]))


def _emit_chain_lookup(lines: List[str], table: List[int]):
    """Emit cascaded if/else to map step_idx → openness value.

    Each unique value gets one branch. Last branch is the else (no condition).
    Stack: step_idx(TOS) → openness(TOS)
    """
    sorted_groups = _group_table_by_value(table)

    if len(sorted_groups) == 1:
        lines.append("  drop")
        lines.append(f"  {sorted_groups[0][0]}")
        return

    last_idx = len(sorted_groups) - 1
    for idx, (openness, steps) in enumerate(sorted_groups):
        if idx > 0:
            lines.append("  else")
        if idx < last_idx:
            _emit_step_match_condition(lines, steps)
            lines.append("  if")
        lines.append(f"    drop {openness}")

    for _ in range(len(sorted_groups) - 1):
        lines.append("  endif")


# ── Position computation (energy × openness → position) ───────────


def _emit_position_from_openness(lines: List[str], min_s: int, range_s: int):
    """Emit position computation from energy and openness.

    Stack on entry: ...batch dur energy openness(TOS)
    Stack on exit:  ...batch dur position(TOS)

    If openness == 0: position = min_s * 100 (skip energy multiply)
    Else: position = min_s * 100 + range_s * (energy * openness / 100)

    Uses single division (energy*openness/100) to keep truncation
    error within ±40 QUS. The old formula with two divisions
    (effective/100 then *range_s/100) gave up to ~140 QUS error.

    Overflow safety: range_s * effective ≤ 40 * 100 = 4000 (fits 16-bit).
    min_pos + 4000 = 8000 max (fits 16-bit).
    """
    min_pos = min_s * 100

    lines.append("  dup 0 equals")
    lines.append("  if")
    lines.append("    drop drop")  # drop openness and energy
    lines.append(f"    {min_pos}")
    lines.append("  else")
    # effective = energy * openness / 100 (single truncation, ≤40 QUS)
    # position = min_pos + range_s * effective
    lines.append("    swap")  # ...batch dur openness energy
    lines.append("    over")  # ...batch dur openness energy openness
    lines.append("    times 100 divide")  # effective = energy * openness / 100
    lines.append(f"    {range_s} times {min_pos} plus")  # position
    lines.append("    swap drop")  # drop openness, keep position
    lines.append("  endif")


# ── Script assembly ────────────────────────────────────────────────


def generate_process_batch() -> str:
    """Generate the process_batch loop subroutine.

    Consumes beat data from the stack, calling the decoder for each beat.
    Stops when only the step counter variable remains (depth <= 1).
    """
    return (
        "sub process_batch\n"
        "  begin depth 1 greater_than while\n"
        "    decoder_frame\n"
        "  repeat\n"
        "  return"
    )


def _emit_per_channel_command(
    lines: List[str], channels: List[int], cmd: str, value: int
):
    """Emit a command applied to each channel (speed, acceleration).

    Uses counter loop for contiguous-from-0 channels, unrolls otherwise.
    """
    contiguous = channels == list(range(len(channels)))
    if contiguous:
        lines.append("  0")
        lines.append(f"  begin dup {len(channels)} less_than while")
        lines.append(f"    {value} over {cmd}")
        lines.append("    1 plus")
        lines.append("  repeat drop")
    else:
        for ch in channels:
            lines.append(f"  {value} {ch} {cmd}")


def generate_play_subroutine(
    quantized_beats: List[Dict],
    pattern_name: str,
    smooth: bool,
    channels: List[int],
    accel: Optional[int] = None,
) -> str:
    """Generate the play subroutine with batched data.

    Args:
        quantized_beats: Output from quantize_beats()
        pattern_name: Used for naming
        smooth: Whether speed byte is included
        channels: Channel numbers for speed/accel setup
        accel: Acceleration value to set per channel (None = skip)

    Returns:
        Maestro script source for the play subroutine
    """
    batch_size = SMOOTH_BATCH_SIZE if smooth else SNAPPY_BATCH_SIZE
    num_beats = len(quantized_beats)

    if num_beats == 0:
        return f"sub play_{pattern_name}\n  return"

    lines = [f"sub play_{pattern_name}"]

    # Speed setup: all channels to speed 0
    if not smooth:
        lines.append("  # Speed setup: all channels to 0")
        _emit_per_channel_command(lines, channels, "speed", 0)

    # Acceleration setup for wave-family patterns
    if accel is not None:
        lines.append(f"  # Acceleration setup: {accel} per channel")
        _emit_per_channel_command(lines, channels, "acceleration", accel)

    # Step counter at stack position 0
    lines.append("  0")

    # Emit batches
    for batch_idx in range(0, num_beats, batch_size):
        batch_end = min(batch_idx + batch_size, num_beats)
        batch_beats = quantized_beats[batch_idx:batch_end]

        lines.append(
            f"  # Batch {batch_idx // batch_size + 1}: "
            f"beats {batch_idx + 1}-{batch_end}"
        )

        # Push beats in REVERSE order (LIFO: first beat processed first)
        values = []
        for beat in reversed(batch_beats):
            if smooth:
                values.extend([beat["duration"], beat["energy"], beat["speed"]])
            else:
                values.extend([beat["duration"], beat["energy"]])

        # Emit values as a line (compiler will LITERAL8_N batch them)
        # Split into lines of reasonable width
        val_strs = [str(v) for v in values]
        chunk_size = 20
        for i in range(0, len(val_strs), chunk_size):
            chunk = val_strs[i : i + chunk_size]
            lines.append("  " + " ".join(chunk))

        lines.append("  process_batch")

    # Cleanup: drop step counter
    lines.append("  drop")
    lines.append("  return")

    return "\n".join(lines)


def generate_optimized_script(
    pattern: str,
    beats: List[Dict],
    panels: List[Dict],
    mood: Optional[Dict] = None,
) -> str:
    """Generate a complete optimized Maestro script for a song.

    Args:
        pattern: Pattern name (e.g., "burst", "flutter", "breathe")
        beats: List of {"energy": float, "duration_ms": float} dicts
        panels: List of {"channel": int, "min": int, "max": int, "range_pct": int}
        mood: Optional {"intensityMod": float, "speedMod": float}

    Returns:
        Complete Maestro script source code

    Raises:
        ValueError: If pattern is not supported or beats is empty (for
            dynamic patterns; static patterns don't require beats)
    """
    if pattern in FLAT_ONLY_PATTERNS:
        raise ValueError(
            f"Pattern '{pattern}' requires flat encoding (pre-computed positions)"
        )

    if pattern in STATIC_PATTERNS:
        return _generate_static_script(pattern, panels)

    if not beats:
        raise ValueError("No beats provided")

    all_patterns = {
        **CATEGORY_A_PATTERNS,
        **CATEGORY_B_PATTERNS,
        **CATEGORY_C_PATTERNS,
    }
    if pattern not in all_patterns:
        raise ValueError(
            f"Pattern '{pattern}' not supported. Available: "
            + ", ".join(sorted(all_patterns.keys()))
        )

    pat_def = all_patterns[pattern]
    smooth = pat_def["smooth"]
    accel = pat_def.get("accel")

    # Extract mood settings
    intensity_mod = 1.0
    speed_mod = 1.0
    if mood:
        intensity_mod = mood.get("intensityMod", 1.0)
        speed_mod = mood.get("speedMod", 1.0)

    # Quantize beats
    quantized = quantize_beats(
        beats,
        intensity_mod=intensity_mod,
        speed_mod=speed_mod,
        smooth=smooth,
    )

    # Compute shared constants from panels
    channels = sorted(p["channel"] for p in panels)
    min_vals = [p["min"] for p in panels]
    max_vals = [p["max"] for p in panels]
    range_pcts = [p.get("range_pct", 100) for p in panels]

    if (
        len(set(min_vals)) == 1
        and len(set(max_vals)) == 1
        and len(set(range_pcts)) == 1
    ):
        min_s = min_vals[0] // 100
        range_s = (max_vals[0] - min_vals[0]) // 100 * range_pcts[0] // 100
    else:
        avg_min = sum(min_vals) // len(min_vals)
        avg_max = sum(max_vals) // len(max_vals)
        avg_range = sum(range_pcts) // len(range_pcts)
        min_s = avg_min // 100
        range_s = (avg_max - avg_min) // 100 * avg_range // 100

    # Build script
    parts = [f"# Optimized Maestro script: {pattern} ({len(beats)} beats)"]

    # Decoder subroutine (named <pattern>_frame)
    if pattern in CATEGORY_A_PATTERNS:
        decoder = generate_category_a_decoder(
            pattern, channels, min_s, range_s, smooth=smooth
        )
    elif pattern in CATEGORY_B_PATTERNS:
        decoder = generate_category_b_decoder(
            pattern, channels, min_s, range_s, smooth=smooth
        )
    elif pattern in CATEGORY_C_PATTERNS:
        decoder = generate_category_c_decoder(
            pattern, channels, min_s, range_s, smooth=smooth
        )
    parts.append("")
    parts.append(decoder)

    # Process batch subroutine
    process_batch = generate_process_batch().replace(
        "decoder_frame", f"{pattern}_frame"
    )
    parts.append("")
    parts.append(process_batch)

    # Play subroutine with batched data
    play = generate_play_subroutine(quantized, pattern, smooth, channels, accel=accel)
    parts.append("")
    parts.append(play)

    return "\n".join(parts)


def _generate_static_script(pattern: str, panels: List[Dict]) -> str:
    """Generate script for static patterns (open_all, close_all, nothing)."""
    lines = [f"# Static pattern: {pattern}"]
    lines.append(f"sub play_{pattern}")

    if pattern == "nothing":
        lines.append("  return")
    elif pattern == "open_all":
        for p in sorted(panels, key=lambda x: x["channel"]):
            pos = p["max"]
            lines.append(f"  {pos} {p['channel']} servo")
        lines.append("  return")
    elif pattern == "close_all":
        for p in sorted(panels, key=lambda x: x["channel"]):
            pos = p["min"]
            lines.append(f"  {pos} {p['channel']} servo")
        lines.append("  return")

    return "\n".join(lines)


def estimate_optimized_size(
    pattern: str,
    num_beats: int,
    num_channels: int,
) -> int:
    """Estimate compiled bytecode size for an optimized script.

    Args:
        pattern: Pattern name
        num_beats: Number of beats in the song
        num_channels: Number of channels

    Returns:
        Estimated size in bytes
    """
    if pattern in STATIC_PATTERNS:
        return num_channels * 4 + 1  # pos + ch + servo per ch + return

    all_patterns = {
        **CATEGORY_A_PATTERNS,
        **CATEGORY_B_PATTERNS,
        **CATEGORY_C_PATTERNS,
    }
    if pattern not in all_patterns:
        return -1  # Unknown

    pat = all_patterns[pattern]
    smooth = pat["smooth"]
    batch_size = SMOOTH_BATCH_SIZE if smooth else SNAPPY_BATCH_SIZE
    bytes_per_beat = 3 if smooth else 2

    # Decoder subroutine size depends on category and channel count
    if pattern in CATEGORY_A_PATTERNS:
        decoder_size = 100 if smooth else 68
    elif pattern in CATEGORY_B_PATTERNS:
        # Per-channel decoder: ~30-50 bytes per channel + overhead
        per_ch = 50 if smooth else 35
        decoder_size = per_ch * num_channels + 40
    else:
        # Category C: shared lookup + per-channel code
        decoder_size = 80 + 25 * num_channels

    # Process batch subroutine
    process_batch_size = 12

    # Data: LITERAL8_N batches
    num_batches = math.ceil(num_beats / batch_size)
    data_size = sum(
        min(batch_size, num_beats - i * batch_size) * bytes_per_beat
        + 2  # +2 for LITERAL8_N header
        for i in range(num_batches)
    )

    # Batch calls
    batch_calls_size = num_batches

    # Speed/accel setup
    setup_size = 21 if not smooth else 0
    if pat.get("accel") is not None:
        setup_size += 21

    # Play subroutine overhead
    overhead = 7

    return (
        decoder_size
        + process_batch_size
        + data_size
        + batch_calls_size
        + setup_size
        + overhead
    )


def namespace_script(script: str, index: int) -> str:
    """Add index suffix to all subroutine names in a script.

    Prevents name collisions when multiple optimized songs are
    combined into a single compiled script.

    Args:
        script: Maestro script source code
        index: Song index (0, 1, 2, ...)

    Returns:
        Script with all subroutine names suffixed with _<index>
    """
    # Find all subroutine definitions
    sub_names = re.findall(r"^sub\s+(\S+)", script, re.MULTILINE)
    if not sub_names:
        return script

    result = script
    for name in sub_names:
        result = re.sub(r"\b" + re.escape(name) + r"\b", f"{name}_{index}", result)
    return result
