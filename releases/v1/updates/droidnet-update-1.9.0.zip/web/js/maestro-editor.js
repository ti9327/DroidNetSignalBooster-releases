/**
 * maestro-editor.js - CodeMirror-based editor for Maestro scripting language
 *
 * Self-contained IIFE that provides:
 *   1. Maestro language mode (syntax highlighting via Simple Mode)
 *   2. Editor initialization (CodeMirror.fromTextArea)
 *   3. Lint integration (debounced compile check via /api/maestro/compile)
 *   4. Error annotation management (underlines + line widgets)
 *   5. Autocomplete (static keywords + dynamic subs/labels)
 *   6. Public wrapper API on window.maestroEditor
 *
 * Loaded AFTER codemirror.min.js, all addon files, and the DOM textarea.
 * Uses var/function expressions (no let/const/arrow) for older Chromium compat.
 */
(function () {
  "use strict";

  // =========================================================================
  // 1. Maestro Language Mode (Simple Mode)
  // =========================================================================

  CodeMirror.defineSimpleMode("maestro", {
    start: [
      // Comments: # or // to end of line
      { regex: /#.*/, token: "comment" },
      { regex: /\/\/.*/, token: "comment" },

      // Numbers: integers including negative
      { regex: /-?\d+/, token: "number" },

      // Label definitions: word followed by colon (but not part of operators)
      { regex: /[a-zA-Z_]\w*:/, token: "def" },

      // Control flow keywords
      {
        regex: /\b(?:begin|repeat|while|if|else|endif|goto|sub|return)\b/,
        token: "keyword",
      },

      // Servo / timing commands (builtin)
      {
        regex:
          /\b(?:servo|servo_8bit|speed|acceleration|delay|get_position|get_moving_state)\b/,
        token: "builtin",
      },

      // Stack operations (builtin)
      {
        regex: /\b(?:dup|drop|swap|over|rot|pick|depth|roll)\b/,
        token: "builtin",
      },

      // Hardware / IO commands (atom)
      {
        regex:
          /\b(?:led_on|led_off|pwm|peek|poke|serial_send_byte)\b/,
        token: "atom",
      },

      // Multi-character operators (must come before single-char)
      { regex: /<=|>=|!=|==|&&|\|\||<<|>>/, token: "operator" },

      // Single-character operators
      { regex: /[+\-*/%<>=!&|^~]/, token: "operator" },

      // Remaining identifiers
      { regex: /[a-zA-Z_]\w*/, token: "variable-2" },
    ],
    meta: {
      lineComment: "#",
    },
  });

  // =========================================================================
  // 2. Editor Initialization
  // =========================================================================

  var textarea = document.getElementById("maestro-script-editor");
  if (!textarea) return;
  var cm = CodeMirror.fromTextArea(textarea, {
    mode: "maestro",
    theme: "dracula",
    lineNumbers: true,
    matchBrackets: false,
    indentUnit: 2,
    tabSize: 2,
    indentWithTabs: false,
    lineWrapping: false,
    viewportMargin: Infinity,
    gutters: ["CodeMirror-lint-markers", "CodeMirror-linenumbers"],
  });

  cm.setSize(null, 300);

  // =========================================================================
  // 3. Lint Integration (debounced compile check)
  // =========================================================================

  var lintTimer = null;
  var lintAbort = null;
  var lastLintSource = null;

  function getDeviceSerial() {
    return window.maestroDeviceSerial || "";
  }

  function triggerLint() {
    if (lintTimer) {
      clearTimeout(lintTimer);
    }
    lintTimer = setTimeout(function () {
      lintTimer = null;
      runLint();
    }, 700);
  }

  function runLint() {
    var deviceSerial = getDeviceSerial();
    if (!deviceSerial) {
      return;
    }

    var script = cm.getValue();

    // Skip if source has not changed since last successful lint
    if (script === lastLintSource) {
      return;
    }

    // Cancel any in-flight request
    if (lintAbort) {
      lintAbort.abort();
    }
    lintAbort = new AbortController();

    var body = JSON.stringify({
      device_serial: deviceSerial,
      script: script,
    });

    fetch("/api/maestro/compile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body,
      signal: lintAbort.signal,
    })
      .then(function (resp) {
        if (!resp.ok) return null;
        return resp.json();
      })
      .then(function (data) {
        if (!data) return;
        if (data.success) {
          lastLintSource = script;
          clearEditorErrors();
        } else if (data.errors && data.errors.length) {
          lastLintSource = script;
          setEditorErrors(data.errors);
        }
      })
      .catch(function () {
        // Network error or abort -- silently ignore
      });
  }

  cm.on("change", triggerLint);

  // =========================================================================
  // 4. Error Annotation Management
  // =========================================================================

  var errorMarks = [];
  var errorWidgets = [];
  var ERROR_LINE_RE = /^Line (\d+):\s*(.*)$/;

  function clearEditorErrors() {
    var i;
    for (i = 0; i < errorMarks.length; i++) {
      errorMarks[i].clear();
    }
    errorMarks = [];
    for (i = 0; i < errorWidgets.length; i++) {
      errorWidgets[i].clear();
    }
    errorWidgets = [];
  }

  function setEditorErrors(errors) {
    clearEditorErrors();

    var i, match, lineNum, msg, lineText, from, to, node;

    for (i = 0; i < errors.length; i++) {
      match = ERROR_LINE_RE.exec(errors[i]);
      if (!match) {
        continue;
      }

      // Compiler is 1-indexed, CodeMirror is 0-indexed
      lineNum = parseInt(match[1], 10) - 1;
      msg = match[2];

      if (lineNum < 0 || lineNum >= cm.lineCount()) {
        continue;
      }

      lineText = cm.getLine(lineNum);
      from = { line: lineNum, ch: 0 };
      to = { line: lineNum, ch: lineText.length };

      // Underline the error line
      errorMarks.push(
        cm.markText(from, to, { className: "cm-error-underline" })
      );

      // Widget below the line showing the message
      node = document.createElement("div");
      node.className = "cm-error-widget";
      node.textContent = msg;
      errorWidgets.push(cm.addLineWidget(lineNum, node, { coverGutter: false }));
    }
  }

  // =========================================================================
  // 5. Autocomplete
  // =========================================================================

  var KEYWORDS = [
    // Control flow
    "begin",
    "repeat",
    "while",
    "if",
    "else",
    "endif",
    "goto",
    "sub",
    "return",
    // Servo / timing (builtin)
    "servo",
    "servo_8bit",
    "speed",
    "acceleration",
    "delay",
    "get_position",
    "get_moving_state",
    // Stack ops (builtin)
    "dup",
    "drop",
    "swap",
    "over",
    "rot",
    "pick",
    "depth",
    "roll",
    // Hardware (atom)
    "led_on",
    "led_off",
    "pwm",
    "peek",
    "poke",
    "serial_send_byte",
  ];

  var SUB_RE = /\bsub\s+(\w+)/g;
  var LABEL_RE = /^(\w+):/gm;

  function getDynamicSymbols() {
    var src = cm.getValue();
    var symbols = {};
    var m;

    SUB_RE.lastIndex = 0;
    while ((m = SUB_RE.exec(src)) !== null) {
      symbols[m[1]] = true;
    }

    LABEL_RE.lastIndex = 0;
    while ((m = LABEL_RE.exec(src)) !== null) {
      symbols[m[1]] = true;
    }

    return Object.keys(symbols);
  }

  function maestroHint(editor) {
    var cursor = editor.getCursor();
    var token = editor.getTokenAt(cursor);
    var start = token.start;
    var end = cursor.ch;
    var prefix = token.string.slice(0, end - start);

    // Only trigger for 2+ word characters
    if (!/^\w{2,}$/.test(prefix)) {
      return null;
    }

    var dynamic = getDynamicSymbols();
    var all = KEYWORDS.concat(dynamic);

    // Deduplicate
    var seen = {};
    var unique = [];
    var i, word;
    for (i = 0; i < all.length; i++) {
      word = all[i];
      if (!seen[word]) {
        seen[word] = true;
        unique.push(word);
      }
    }

    // Filter by prefix (case-insensitive)
    var lowerPrefix = prefix.toLowerCase();
    var matches = [];
    for (i = 0; i < unique.length; i++) {
      if (unique[i].toLowerCase().indexOf(lowerPrefix) === 0) {
        matches.push(unique[i]);
      }
    }

    if (matches.length === 0) {
      return null;
    }

    matches.sort();

    return {
      list: matches,
      from: CodeMirror.Pos(cursor.line, start),
      to: CodeMirror.Pos(cursor.line, end),
    };
  }

  // Trigger autocomplete on typing 2+ word characters
  cm.on("inputRead", function (instance, changeObj) {
    if (changeObj.origin !== "+input") {
      return;
    }
    var cursor = instance.getCursor();
    var token = instance.getTokenAt(cursor);
    var prefix = token.string.slice(0, cursor.ch - token.start);
    if (/^\w{2,}$/.test(prefix)) {
      CodeMirror.commands.autocomplete(instance, maestroHint, {
        completeSingle: false,
      });
    }
  });

  // Ctrl-Space to force autocomplete
  cm.setOption("extraKeys", {
    "Ctrl-Space": function (instance) {
      CodeMirror.commands.autocomplete(instance, maestroHint, {
        completeSingle: false,
      });
    },
  });

  // =========================================================================
  // 6. Public Wrapper API
  // =========================================================================

  window.maestroEditor = {
    getValue: function () {
      return cm.getValue();
    },
    setValue: function (text) {
      cm.setValue(text || "");
      clearEditorErrors();
      lastLintSource = null;
    },
    setErrors: function (errors) {
      setEditorErrors(errors);
    },
    clearErrors: function () {
      clearEditorErrors();
    },
    setReadOnly: function (bool) {
      cm.setOption("readOnly", bool ? "nocursor" : false);
    },
    focus: function () {
      cm.focus();
    },
    on: function (event, cb) {
      cm.on(event, cb);
    },
    refresh: function () {
      cm.refresh();
    },
    cm: cm,
  };
})();
